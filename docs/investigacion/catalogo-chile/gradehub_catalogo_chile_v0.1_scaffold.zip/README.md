# Catálogo Universitario de Chile para GradeHub — Paquete Base y Backlog (`v0.1`)

- **Fecha de corte:** `2026-11-26`
- **Versión de esquema:** `1.0.0`
- **Estado del paquete:** `scaffold_y_backlog_sin_extraccion_web`
- **Codificación:** UTF-8 (sin BOM), saltos de línea LF

## 1. Alcance real y limitación crítica de esta sesión

Este paquete fue generado en un entorno **sin acceso a internet ni descarga de archivos externos** (`NO_EGRESS`). Por respeto estricto a las reglas de integridad de GradeHub —*usar `null` para cualquier dato sin evidencia, separar registros confirmados de candidatos y respaldar todo registro verificado con una fuente oficial consultada*—:

1. **Registros confirmados en vivo: `0`.** Todos los archivos oficiales de producción (`fuentes.jsonl`, `universidades.jsonl`, `carreras.jsonl`, `ofertas.jsonl`, `mallas.jsonl`, `ramos.jsonl`, `malla_ramos.jsonl`, `requisitos.jsonl`) se entregan deliberadamente vacíos para evitar que Claude integre datos no verificados o códigos oficiales inventados.
2. **Semilla no verificada separada (`candidatos/universidades_candidatas.jsonl`):** Contiene **61 universidades chilenas** (18 estatales CRUCH, 12 privadas CRUCH, 15 privadas adscritas al Sistema de Acceso, 9 privadas fuera del Sistema de Acceso o en transición y 7 universidades en cierre o históricas conocidas), con IDs deterministas (`univ_cl_<slug>`), siglas y aliases de búsqueda estudiantil, pero con `null` en todos los códigos oficiales (`mineduc`, `sies`, `demre`, `rut`), regiones y sedes hasta descargar el directorio vivo de Mineduc/SIES.
3. **Infraestructura lista para ingestión en Claude:** Esquemas JSON Draft 2020-12 completos (`schema/`), ejemplo relacional sintético (`schema/ejemplo_cruces.json`), tabla de cobertura nacional (`cobertura.csv`), backlog priorizado (`pendientes.jsonl`) y validador automático (`scripts/validar_paquete.py`).

## 2. Cómo leer el paquete

| Ruta | Propósito | Registros actuales |
| :--- | :--- | ---: |
| `manifest.json` | Metadatos del paquete, versión de esquema, conteos reales y hashes SHA-256 | 1 |
| `schema/*.schema.json` | Contratos JSON Schema (Draft 2020-12) para las 9 entidades | 9 archivos |
| `schema/ejemplo_cruces.json` | Ejemplo sintético (no real) de cómo enlazan todas las entidades | 1 archivo |
| `fuentes.jsonl` | Fuentes oficiales verificadas con URL, fecha de consulta y ubicación exacta | 0 |
| `universidades.jsonl` | Universidades verificadas contra Mineduc/SIES | 0 |
| `carreras.jsonl` | Carreras de pregrado verificadas | 0 |
| `ofertas.jsonl` | Ofertas por sede, campus, jornada, modalidad y período | 0 |
| `mallas.jsonl` | Planes de estudio oficiales con vigencia y sistema de créditos | 0 |
| `ramos.jsonl` | Asignaturas oficiales por universidad | 0 |
| `malla_ramos.jsonl` | Apariciones de ramos y bloques electivos/reglas dentro de cada malla | 0 |
| `requisitos.jsonl` | Prerrequisitos y correquisitos explícitos con condición publicada | 0 |
| `cobertura.csv` | Denominador preliminar de 61 universidades, métricas reales y próxima fuente | 61 filas |
| `pendientes.jsonl` | Tareas nacionales (Fase 0), decisiones de datos y 1 tarea por universidad | 67 |
| `candidatos/universidades_candidatas.jsonl` | Semilla preliminar de universidades chilenas (NO cargar como confirmada) | 61 |
| `scripts/validar_paquete.py` | Script Python para validar sintaxis, IDs, referencias y política de fuentes | 1 script |

## 3. Decisiones de datos clave para Claude antes de integrar

1. **IDs internos vs. códigos oficiales:** Los IDs del paquete son deterministas (`univ_cl_<slug>`, `car_<slug>`, `ofe_<slug>`, `mal_<slug>`, `ram_<slug>`, `mra_<slug>`, `req_<slug>`, `fnt_<slug>`). Los códigos de Mineduc, SIES y DEMRE viven en `codigos_oficiales` siempre como **texto** (`string` o `null`) para no perder ceros iniciales ni códigos alfanuméricos de SIES (p. ej., `I...S...C...J...V...`).
2. **Créditos incompatibles entre instituciones:** Nunca almacenar `creditos` sin `unidad_creditos`. `10` créditos UC (`creditos_uc`) y `10` `SCT-Chile` representan cargas académicas completamente distintas. Si una malla omite créditos, guardar `null` (nunca `0`).
3. **Colisiones de siglas en búsqueda:** `UA` corresponde tanto a la Universidad de Antofagasta como a la Universidad Autónoma de Chile; `INACAP` y `Santo Tomás` tienen ramas separadas de Universidad, IP y CFT. Los `aliases` y `siglas` solo alimentan el buscador de GradeHub; nunca deben fusionar entidades ni reemplazar `nombre_oficial`.
4. **Ramos homónimos:** Dos ramos llamados *"Cálculo I"* en universidades o planes distintos son entidades independientes salvo que la fuente oficial establezca explícitamente que comparten código y programa dentro de la misma universidad.
5. **Bloques y electivos:** Cuando una malla publica *"Electivo de especialidad"* o *"Elegir 2 de estas 5 asignaturas"*, `malla_ramos.ramo_id` queda en `null`, `nombre_publicado` guarda el texto oficial, `regla_eleccion` modela la regla y `opciones_ramo_ids` vincula los ramos concretos si la fuente los enumera.
6. **Extensiones separadas:** Al descargar bases masivas de SIES/Mineduc, mantener IP/CFT en un directorio separado (`extension_ip_cft/`), posgrados y educación continua en `extension_posgrado/`, y ponderaciones/evaluaciones de programas de curso en `evaluaciones_ramos.jsonl`.

## 4. Orden exacto para continuar (en un entorno con acceso web)

1. **Fase 0 — Bases masivas nacionales (Prioridad 0 en `pendientes.jsonl`):**
   - Descargar Directorio de Instituciones Vigentes y en Cierre de Mineduc (`ayudamineduc.cl`) → poblar `universidades.jsonl` y conciliar contra las 61 candidatas (confirmando estado 2026 de `ubolivariana`, `ulosleones`, `uac`, `inacap_univ`, `ubritanica`, `ulare`, etc.).
   - Descargar bases de Oferta Académica y Matrícula de SIES (`mifuturo.cl`) → poblar `carreras.jsonl` y `ofertas.jsonl` a cobertura nacional completa (100 % de las universidades vigentes con oferta oficial).
   - Descargar Oferta Definitiva de Acceso Mineduc (`acceso.mineduc.cl`) y Nómina Definitiva DEMRE (`demre.cl`) → enriquecer `ofertas.jsonl` con códigos DEMRE y registrar discrepancias en `pendientes.jsonl`.
2. **Fase 1 — Auditoría de brechas en las 7 universidades prioritarias de GradeHub (Prioridad 1):**
   - `UC`, `UCh`, `UAI`, `UAndes`, `UDD` (cobertura existente) y `UDP`, `UNAB` (trabajo en paralelo). Extraer mallas vigentes e históricas, catálogos completos de ramos y comparar contra la base actual de GradeHub antes de fusionar.
3. **Fase 2 — Resto del CRUCH (Prioridad 2, 25 universidades):**
   - 17 estatales restantes (CUECH) + 8 privadas CRUCH restantes (G9 + UAH). Priorizar las de mayor matrícula y catálogos estructurados (`USACH`, `PUCV`, `USM`, `UdeC`, `UACh`, `UV`, `UFRO`, `UTalca`, `UCN`, `UBB`).
4. **Fase 3 — Privadas adscritas al Sistema de Acceso no CRUCH (Prioridad 3, 12 universidades):**
   - `UAUTONOMA`, `UMayor`, `USS`, `UFT`, `UBO`, `UCEN`, `UCSH`, `UAHC`, `UGM`, `UST` (filtrando estrictamente Universidad, no IP/CFT), `UDLA`, `UnACh`.
5. **Fase 4 — Privadas fuera del Sistema de Acceso (Prioridad 4, 8 universidades):**
   - `UNIACC`, `UVM`, `UAC`, `UMC`, `UDALBA` (ex UPV), `USEK`, `UB`, `ULL`.
6. **Fase 5 — Instituciones en cierre o históricas (Prioridad 5, 7+ universidades):**
   - Verificar listado oficial de cierre en Mineduc/CNED (`INACAP Universidad`, `ULARE`, `UPACIFICO`, `UNICIT`, `ARCIS`, `UDELMAR`, `UCINF`, `UCBC`) y registrar solo oferta histórica verificada.
7. **Validación tras cada lote:** Ejecutar `python3 scripts/validar_paquete.py` y comprobar muestra manual contra los PDF originales (especialmente tablas con columnas combinadas, menciones y electivos).
