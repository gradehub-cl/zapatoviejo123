# GradeHub · Catálogo de universidades de Chile

Corte de la recopilación: 26 de noviembre de 2026. Paquete 0.2.0.

## Cobertura comprobada

| Entidad | Registros |
| --- | ---: |
| Universidades verificadas | 55 |
| Universidades vigentes según las fuentes consultadas | 53 |
| Universidades en cierre | 2 |
| Universidades con ofertas de pregrado SIES 2026 | 53 |
| Carreras agrupadas de pregrado | 3587 |
| Ofertas de pregrado por sede, jornada, modalidad y versión | 7144 |
| Ofertas de pregrado con admisión nueva según SIES | 3264 |
| Ofertas de pregrado en convenio de reubicación | 49 |
| Ofertas de posgrado o postítulo, en extensión aparte | 8781 |
| Mallas, ramos y requisitos extraídos | 0 |

## Fuentes y criterios de integración

- El [directorio Mineduc de mayo de 2026](https://ayudamineduc.cl/sites/default/files/ies_vig_may_26.xlsx) da el registro oficial y el nombre de las universidades, con fila y huella del archivo en `fuentes.jsonl`.
- La [base SIES 2026](https://www.mifuturo.cl/wp-content/uploads/2026/06/Oferta_Academica_2026_SIES_05_06_2026_WEB_E.xlsx) permite verificar la oferta informada por cada institución. El [glosario SIES](https://www.mifuturo.cl/wp-content/uploads/2026/06/Glosario_Oferta_Academica_2010_al_2026_SIES_WEB_EE-1.pdf) documenta los campos. `trazabilidad_sies.csv` conserva hoja, fila, código, versión, sede, régimen y vigencia literal.
- Cada fila de pregrado de las instituciones universitarias de SIES aparece en `ofertas.jsonl`. Los campos `admision_nueva` y `convenio_reubicacion` distinguen admisión habitual, continuidad y reubicación.
- Las carreras se agrupan por institución, código de carrera SIES, nombre, nivel, tipo de plan y descripción de plan especial. Cada sede, jornada, modalidad y versión sigue en su oferta. Se conserva la ortografía publicada por SIES. Los ceros que SIES utiliza para indicar ausencia de código DEMRE se expresan como `null`.
- `gradehub_universidades.csv` cruza los IDs con los códigos del PR borrador [#1367](https://github.com/gradehub-cl/zapatoviejo123/pull/1367). Un código ya usado, como `fen`, conserva su identidad. El cruce no indica que el perfil esté habilitado en Supabase.
- La Universidad Tecnológica de Chile INACAP y la Universidad La República se identifican como en cierre. Para La República se conserva también el [anuncio oficial del administrador de cierre](https://educacionsuperior.mineduc.cl/2026/04/28/subsecretaria-de-educacion-superior-formaliza-el-nombramiento-de-fernando-de-la-jara-goyeneche-como-administrador-de-cierre-de-la-universidad-la-republica/). La oferta de INACAP corresponde al registro universitario, que es distinto de su IP y CFT. Para Universidad Los Leones el directorio aporta identidad; falta verificar la oferta de pregrado.
- `extension_posgrado/` contiene los registros SIES de posgrado y postítulo aparte. El paquete cubre universidades y no incorpora IP ni CFT.
- El cruce con [la publicación de admisión 2027](https://acceso.mineduc.cl/wp-content/uploads/2026/10/oferta-202730-10-26_compressed-1.pdf) y la extracción de mallas, ramos y requisitos siguen pendientes. Los JSONL de esas entidades conservan el esquema de ingestión. Las seis instituciones históricas de la semilla que requieren verificación propia permanecen en `candidatos/`.

## Verificación

Se ejecutó el validador original de relaciones, se comprobaron los esquemas de datos raíz con JSON Schema Draft 2020-12 y se conciliaron los conteos con las hojas oficiales. El manifiesto registra tamaño, conteo y SHA-256. Para repetir la validación relacional tras extraer el ZIP, ejecuta `python3 scripts/validar_paquete.py`.
