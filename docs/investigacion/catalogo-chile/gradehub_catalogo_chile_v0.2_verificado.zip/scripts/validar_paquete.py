#!/usr/bin/env python3
"""Validador de integridad para el paquete de catalogo universitario chileno (GradeHub).

Verifica:
1. Lectura UTF-8 y sintaxis JSON valida en cada linea de todos los .jsonl y .json.
2. Unicidad de IDs por archivo.
3. Integridad referencial cruzada (universidad_id, carrera_id, oferta_id, malla_id, ramo_id, fuente_ids).
4. Consistencia institucional: todo ramo en malla_ramos y requisitos pertenece a la misma universidad de la malla.
5. Reglas de calidad: codigos oficiales como texto, creditos acompanados de unidad_creditos,
   y fuentes oficiales obligatorias en todos los registros confirmados.
"""

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

CONFIRMED_JSONL = [
    "fuentes.jsonl",
    "universidades.jsonl",
    "carreras.jsonl",
    "ofertas.jsonl",
    "mallas.jsonl",
    "ramos.jsonl",
    "malla_ramos.jsonl",
    "requisitos.jsonl",
]


def load_jsonl(path: Path, errors: list[str]) -> list[dict]:
    records = []
    if not path.exists():
        errors.append(f"Archivo faltante: {path.relative_to(ROOT)}")
        return records
    with path.open("r", encoding="utf-8") as f:
        for idx, line in enumerate(f, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                obj = json.loads(stripped)
                if not isinstance(obj, dict):
                    errors.append(f"{path.name}:{idx}: la linea no es un objeto JSON")
                else:
                    records.append(obj)
            except json.JSONDecodeError as exc:
                errors.append(f"{path.name}:{idx}: JSON invalido ({exc})")
    return records


def check_unique_ids(records: list[dict], fname: str, errors: list[str]) -> dict[str, dict]:
    index = {}
    for i, rec in enumerate(records, start=1):
        rid = rec.get("id")
        if not isinstance(rid, str) or not rid.strip():
            errors.append(f"{fname} registro #{i}: 'id' faltante o no es texto")
            continue
        if rid in index:
            errors.append(f"{fname}: id duplicado '{rid}'")
        index[rid] = rec
    return index


def main() -> int:
    errors: list[str] = []

    # 1. Validar JSON de manifest y schemas
    for json_file in [ROOT / "manifest.json", *sorted((ROOT / "schema").glob("*.json"))]:
        try:
            json.loads(json_file.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"{json_file.relative_to(ROOT)}: JSON invalido ({exc})")

    # 2. Cargar JSONL confirmados
    data = {name: load_jsonl(ROOT / name, errors) for name in CONFIRMED_JSONL}
    pendientes = load_jsonl(ROOT / "pendientes.jsonl", errors)
    candidatos = load_jsonl(ROOT / "candidatos" / "universidades_candidatas.jsonl", errors)

    # 3. IDs unicos
    fuentes_idx = check_unique_ids(data["fuentes.jsonl"], "fuentes.jsonl", errors)
    univs_idx = check_unique_ids(data["universidades.jsonl"], "universidades.jsonl", errors)
    carreras_idx = check_unique_ids(data["carreras.jsonl"], "carreras.jsonl", errors)
    ofertas_idx = check_unique_ids(data["ofertas.jsonl"], "ofertas.jsonl", errors)
    mallas_idx = check_unique_ids(data["mallas.jsonl"], "mallas.jsonl", errors)
    ramos_idx = check_unique_ids(data["ramos.jsonl"], "ramos.jsonl", errors)
    malla_ramos_idx = check_unique_ids(data["malla_ramos.jsonl"], "malla_ramos.jsonl", errors)
    reqs_idx = check_unique_ids(data["requisitos.jsonl"], "requisitos.jsonl", errors)
    check_unique_ids(pendientes, "pendientes.jsonl", errors)
    cand_idx = check_unique_ids(candidatos, "candidatos/universidades_candidatas.jsonl", errors)

    # 4. Verificar fuentes en todos los confirmados (excepto fuentes.jsonl)
    for fname in CONFIRMED_JSONL[1:]:
        for rec in data[fname]:
            fids = rec.get("fuente_ids")
            if not isinstance(fids, list) or len(fids) == 0:
                errors.append(f"{fname} ({rec.get('id')}): registro confirmado sin fuente_ids")
                continue
            for fid in fids:
                if fid not in fuentes_idx:
                    errors.append(f"{fname} ({rec.get('id')}): fuente_id inexistente '{fid}'")

    # 5. Codigos oficiales siempre como texto o null
    for rec in data["universidades.jsonl"]:
        for k, v in (rec.get("codigos_oficiales") or {}).items():
            if v is not None and not isinstance(v, str):
                errors.append(f"universidades.jsonl ({rec['id']}): codigo '{k}' debe ser string o null")

    for rec in data["ofertas.jsonl"]:
        for k, v in (rec.get("codigos_oficiales") or {}).items():
            if v is not None and not isinstance(v, str):
                errors.append(f"ofertas.jsonl ({rec['id']}): codigo '{k}' debe ser string o null")

    # 6. Integridad referencial
    for cid, rec in carreras_idx.items():
        if rec.get("universidad_id") not in univs_idx:
            errors.append(f"carreras.jsonl ({cid}): universidad_id inexistente '{rec.get('universidad_id')}'")

    for oid, rec in ofertas_idx.items():
        cid = rec.get("carrera_id")
        uid = rec.get("universidad_id")
        if cid not in carreras_idx:
            errors.append(f"ofertas.jsonl ({oid}): carrera_id inexistente '{cid}'")
        elif carreras_idx[cid].get("universidad_id") != uid:
            errors.append(f"ofertas.jsonl ({oid}): universidad_id no coincide con su carrera")

    for mid, rec in mallas_idx.items():
        cid = rec.get("carrera_id")
        uid = rec.get("universidad_id")
        if cid not in carreras_idx:
            errors.append(f"mallas.jsonl ({mid}): carrera_id inexistente '{cid}'")
        elif carreras_idx[cid].get("universidad_id") != uid:
            errors.append(f"mallas.jsonl ({mid}): universidad_id no coincide con su carrera")
        for oid in rec.get("oferta_ids", []):
            if oid not in ofertas_idx:
                errors.append(f"mallas.jsonl ({mid}): oferta_id inexistente '{oid}'")

    for rid, rec in ramos_idx.items():
        if rec.get("universidad_id") not in univs_idx:
            errors.append(f"ramos.jsonl ({rid}): universidad_id inexistente '{rec.get('universidad_id')}'")
        if rec.get("creditos") is not None and not rec.get("unidad_creditos"):
            errors.append(f"ramos.jsonl ({rid}): tiene creditos sin unidad_creditos")
        cod = rec.get("codigo_oficial")
        if cod is not None and not isinstance(cod, str):
            errors.append(f"ramos.jsonl ({rid}): codigo_oficial debe ser string o null")

    for mrid, rec in malla_ramos_idx.items():
        mid = rec.get("malla_id")
        uid = rec.get("universidad_id")
        rid = rec.get("ramo_id")
        if mid not in mallas_idx:
            errors.append(f"malla_ramos.jsonl ({mrid}): malla_id inexistente '{mid}'")
        elif mallas_idx[mid].get("universidad_id") != uid:
            errors.append(f"malla_ramos.jsonl ({mrid}): universidad_id difiere de la malla '{mid}'")
        if rid is not None:
            if rid not in ramos_idx:
                errors.append(f"malla_ramos.jsonl ({mrid}): ramo_id inexistente '{rid}'")
            elif ramos_idx[rid].get("universidad_id") != uid:
                errors.append(f"malla_ramos.jsonl ({mrid}): ramo '{rid}' pertenece a otra universidad")
        for opt_rid in rec.get("opciones_ramo_ids", []):
            if opt_rid not in ramos_idx:
                errors.append(f"malla_ramos.jsonl ({mrid}): opcion ramo_id inexistente '{opt_rid}'")
            elif ramos_idx[opt_rid].get("universidad_id") != uid:
                errors.append(f"malla_ramos.jsonl ({mrid}): opcion '{opt_rid}' pertenece a otra universidad")

    for qid, rec in reqs_idx.items():
        uid = rec.get("universidad_id")
        mid = rec.get("malla_id")
        dest = rec.get("ramo_destino_id")
        if mid is not None and mid not in mallas_idx:
            errors.append(f"requisitos.jsonl ({qid}): malla_id inexistente '{mid}'")
        if dest not in ramos_idx:
            errors.append(f"requisitos.jsonl ({qid}): ramo_destino_id inexistente '{dest}'")
        elif ramos_idx[dest].get("universidad_id") != uid:
            errors.append(f"requisitos.jsonl ({qid}): ramo_destino_id pertenece a otra universidad")
        for rreq in rec.get("ramos_requeridos_ids", []):
            if rreq not in ramos_idx:
                errors.append(f"requisitos.jsonl ({qid}): ramo requerido inexistente '{rreq}'")
            elif ramos_idx[rreq].get("universidad_id") != uid:
                errors.append(f"requisitos.jsonl ({qid}): ramo requerido '{rreq}' pertenece a otra universidad")

    # 7. Validar cobertura.csv
    cob_path = ROOT / "cobertura.csv"
    if not cob_path.exists():
        errors.append("Archivo faltante: cobertura.csv")
    else:
        with cob_path.open("r", encoding="utf-8", newline="") as f:
            rows = list(csv.DictReader(f))
        cob_ids = [r["universidad_id"] for r in rows]
        if len(cob_ids) != len(set(cob_ids)):
            errors.append("cobertura.csv: universidad_id duplicado")
        for uid in cob_ids:
            if uid not in univs_idx and uid not in cand_idx:
                errors.append(f"cobertura.csv: universidad_id '{uid}' no existe ni en confirmados ni en candidatos")

    # 8. Validar que los candidatos NO se mezclen con confirmados
    for cid, rec in cand_idx.items():
        if rec.get("estado_verificacion") == "confirmado":
            errors.append(f"candidatos/universidades_candidatas.jsonl ({cid}): un candidato no puede marcarse 'confirmado'")

    if errors:
        print(f"FALLO DE VALIDACION ({len(errors)} errores):", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        return 1

    print("VALIDACION EXITOSA: 0 errores.")
    print(f"  Confirmados -> fuentes:{len(fuentes_idx)} univ:{len(univs_idx)} car:{len(carreras_idx)} ofe:{len(ofertas_idx)} mal:{len(mallas_idx)} ram:{len(ramos_idx)} mra:{len(malla_ramos_idx)} req:{len(reqs_idx)}")
    print(f"  Candidatos  -> universidades_candidatas:{len(cand_idx)} | pendientes:{len(pendientes)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
